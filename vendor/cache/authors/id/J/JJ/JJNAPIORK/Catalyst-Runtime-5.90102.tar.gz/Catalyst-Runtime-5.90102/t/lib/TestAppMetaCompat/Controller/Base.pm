package TestAppMetaCompat::Controller::Base;

use strict;
use base qw/Catalyst::Controller/;

1;
